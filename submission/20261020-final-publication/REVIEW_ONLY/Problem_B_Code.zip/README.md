# Problem B code and evidence supplement

This package accompanies *Capacity-Valid Scheduling of a Heterogeneous GPU Cluster*.
The research implementation is frozen at commit
`990846fc89bf714d8e88e458d028d1f0d22712a4` (unchanged core sources).
`package_manifest.json` records the exact bytes of the core, publication sources,
and small evidence files. Publication adapters do not change scheduling, routing,
placement, or validation semantics. Team identity and submission approval are in
the separate report/handoff; this package does not assert that submission occurred.

## Install and quick checks

Use Python 3.11 or newer. The clean extraction was tested with CPython 3.12.3,
NumPy 2.3.5, pandas 2.2.3, and Matplotlib 3.10.8 on Linux. From the ZIP root:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -I smoke.py
.venv/bin/python -I check_evidence.py
.venv/bin/python -I reproduce.py --help
```

On Windows PowerShell, extract the ZIP first, open a terminal in its root, and use:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -X utf8 -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -X utf8 -I smoke.py
.\.venv\Scripts\python.exe -X utf8 -I check_evidence.py
.\.venv\Scripts\python.exe -X utf8 -I reproduce.py --help
```

No activation script or execution-policy change is needed. For later commands,
replace `.venv/bin/python` with `.\.venv\Scripts\python.exe -X utf8`.
The Windows-specific CRLF and missing-`resource` failure modes were reproduced
and checked on Linux; native Windows execution has not been performed here.
The bound/decomposition calculations and all small tests remain enabled when
`resource` is absent; only peak-memory telemetry is unavailable (`null`).
Generated tables use UTF-8/LF; evidence comparison permits LF/CRLF differences
only and still rejects changed numerical values. Package SHA-256 values continue
to identify exact distributed bytes, without newline normalization.

The smoke runs the included, existing small unit tests for atomic gangs, CPU/GPU
co-location, ratio placement, routing, and lower bounds, followed by three CLI
runs on a five-job synthetic fixture. It never reads the official full trace.
The selected Q3 class is `test_q3.Q3Tests`; the historical Git-dependent
`Q3PersistedCLI` class is outside this standalone smoke. The portable CLI is
tested separately, without Git or historical worktrees.
The evidence check regenerates Tables 2-5 from the packaged numerical sources,
checks the stratum aggregates, and checks the 217,578 completion count.
Neither test is a claim that the full matrix has been rerun in a clean environment.

## Official data

Obtain the competition's two original CSV files through the team's authorized
competition materials. Put `node_info_df.csv` and `job_info_clean.csv` in a directory
such as `data/`. Raw CSV and large saved job/node ledgers are deliberately excluded.
No private account, old worktree, Git branch, symlink, or Git installation is needed.
The formal inputs have these SHA-256 values:

- Nodes: `1aba161961a5a4a1a61aa581383c5e5abe3400b59f8597ba8c4eef7597bc9d18`
- Jobs used in formal runs: `ef14d696adc1b5c7847db49b41a068a998c8cd669e63922c92b3f1c3f32eedb0`
- Supplied historical job serialization: `735bc06c3986b1d0c5932236f8685b7204463829118fc6a1d37030e253ed38e1`

The two job byte streams were compared by original ID and exact Decimal-valued
fields; the saved comparison is included. Do not relabel a byte hash as identical.
The loader validates the CPU scale (0.01 vCPU), identifiers, and resource fields.

## Full reproduction commands (not executed for this publication handoff)

Each output directory must be new. C0-C4 use the same complete original population,
90-day horizon of 7,776,000 seconds, shared timer, K=200, and GS1-only ratio placement.
C0 has no substitution and no foreign partition. C1/C2 use Hash-10% at sigma 1/2;
C3/C4 use Shape-filtered at sigma 1/2. Substitution dedicates 60 physical A100 nodes.
The exact configuration for every case is in `frozen_cases.json`.

```sh
.venv/bin/python -I reproduce.py --case C0 --data data --output runs/C0
.venv/bin/python -I reproduce.py --case C1 --data data --output runs/C1
.venv/bin/python -I reproduce.py --case C2 --data data --output runs/C2
.venv/bin/python -I reproduce.py --case C3 --data data --output runs/C3
.venv/bin/python -I reproduce.py --case C4 --data data --output runs/C4
.venv/bin/python -I reproduce.py --case B1 --data data --output runs/B1
.venv/bin/python -I reproduce.py --case B2 --data data --output runs/B2
.venv/bin/python -I reproduce.py --case full-A1 --data data --output runs/full-A1
.venv/bin/python -I reproduce.py --case full-H1 --data data --output runs/full-H1
.venv/bin/python -I reproduce.py --case full-C1 --data data --output runs/full-C1
.venv/bin/python problems/2026_gpu_scheduling/experiments/eda_analysis.py --data data --out runs/Q1
```

Expected scheduler outputs are `jobs.csv.gz`, `placements.csv.gz`, and `metrics.json`.
The portable runner records source hashes and uses the original functions. It does
not claim independent validation merely because scheduling returned. The unchanged
validation functions are included under `gpu_scheduling/validation.py` and
`q3_validation.py`; original formal validation reports are in the source index.
The complete integrated matrix, and fourteen historical Q2 ledgers, were validated
before this publication task. Their large local-only ledgers are not in this ZIP.
The full experiments above may be expensive and were **not executed** for packaging.

## Publication rebuild

The only final TeX entry is
`problems/2026_gpu_scheduling/paper/final_publication/document.tex`.
Tables are generated by `generate.py`, using explicit C0-C4 keys, not row positions.
Figures are included as vectors. Optional figure redraws require the official CSV
for Q1, while donor sensitivity uses only small saved evidence:

```sh
.venv/bin/python problems/2026_gpu_scheduling/paper/final_publication/plot_q1.py --data data
.venv/bin/python problems/2026_gpu_scheduling/paper/final_publication/plot_sensitivity.py
.venv/bin/python problems/2026_gpu_scheduling/paper/final_publication/build.py --compiler tectonic --out build/report
```

Tectonic 0.17.0 was used; install it separately. First use can download TeX packages.
Font files, the compiler binary, and third-party official documents are not bundled.
For optional PDF extraction checks, install `pymupdf==1.26.5` and run:

```sh
.venv/bin/python problems/2026_gpu_scheduling/paper/final_publication/verify_pdf.py build/report/document.pdf --out build/pdf_checks.json
```

This verifies actual PDF cells and fonts; visual page review remains separate.
Read `paper_evidence_index.md` for every table/figure, source field, population,
historical alias, and distribution restriction. Source records with private paths
are distributed as explicitly labelled portable copies; original-byte hashes and
the transformation are in `package_manifest.json`.
