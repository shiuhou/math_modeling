import numpy as np, time, sys
from p2_sim import *
which=sys.argv[1]
t0=time.time()
if which=='hol':
    st=sim('hol','sjf'); summ('SJF-HOL',st); np.save('p2_st_sjfhol.npy',st)
if which=='skip':
    st,g=sim('skip','sjf',log_gang=True); summ('SJF-skip(scan500)',st); np.save('p2_st_sjfskip.npy',st)
    g=np.array(g); j=g[:,0].astype(int); fb=g[:,1]; rel=g[:,2]
    ov=(r[j]>7*86400)&(st[j]<90*86400)
    print('k>=2 starts in overload window:',ov.sum(),' with free_before==0:',(fb[ov]==0).sum(),' of those released>=k:',((fb[ov]==0)&(rel[ov]>=k[j][ov])).sum())
if which=='easy':
    st=sim('easy','sjf'); summ('SJF-EASY(scan500)',st); np.save('p2_st_sjfeasy.npy',st)
if which=='decouple':
    st=sim('hol','sjf',lane=(50,3600),lane_keep=True,mice_key='fcfs'); summ('lane R50 mice FCFS-HOL',st)
    si=sim('hol','sjf',lane=(50,3600),mice_key='fcfs',iso=50)
    mice=p<=3600
    d=st[mice]-si[mice]
    print('decoupling test: mice n',mice.sum(),' violations (lane start > iso start + 1e-6):',int((d>1e-6).sum()),' max(lane-iso) s:',d.max(),' iso mice max wait h:',np.nanmax((si-r)[mice])/3600,' lane mice max wait h:',np.nanmax((st-r)[mice])/3600)
print('sec',time.time()-t0)
