import pandas as pd, numpy as np, heapq, sys, time
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])

def place(fg,fc,k,g,c):
    with np.errstate(divide='ignore',invalid='ignore'):
        fit=np.minimum(fg//g, np.where(c>0, np.floor(fc/c+1e-9), 10**6)).astype(int)
    if fit.sum()<k: return None
    idx=np.nonzero(fit)[0]
    # best fit: most loaded first (least free gpu, then least free cpu)
    o=idx[np.lexsort((fc[idx],fg[idx]))]
    alloc=[];need=k
    for i in o:
        x=min(fit[i],need); alloc.append((i,x)); need-=x
        if need==0: break
    return alloc

def simulate(d,capg,capc,policy,mode='node',guard=None):
    r=d.submit_time.values.astype(float); p=d.duration.values.astype(float)
    k=d.worker_num.values.astype(int); g=d.gpu_request.values.astype(float); c=d.cpu_request.values.astype(float)
    if mode=='pooled':  # relax per-node packing: one giant node
        capg=np.array([capg.sum()]); capc=np.array([capc.sum()])
    if mode=='nogang':  # relax gang: workers independent
        rep=np.repeat(np.arange(len(r)),k); r,p,g,c=r[rep],p[rep],g[rep],c[rep]; k=np.ones(len(r),int)
    n=len(r); fg=capg.astype(float).copy(); fc=capc.astype(float).copy()
    order=np.argsort(r,kind='stable'); start=np.full(n,np.nan)
    key={'fcfs':lambda j:(r[j],j),'gfcfs':lambda j:(r[j],j),'sjf':lambda j:(p[j],j),'saf':lambda j:(p[j]*k[j]*g[j],j)}[policy]
    Q=[];run=[];ai=0
    while ai<n or Q or run:
        ta=r[order[ai]] if ai<n else np.inf; te=run[0][0] if run else np.inf; t=min(ta,te)
        while run and run[0][0]<=t:
            e,j,alloc=heapq.heappop(run)
            for i,x in alloc: fg[i]+=x*g[j]; fc[i]+=x*c[j]
        while ai<n and r[order[ai]]<=t:
            j=order[ai]; ai+=1; heapq.heappush(Q,(key(j),j))
        sk=[]; blocked_head=None
        while Q:
            it=heapq.heappop(Q); j=it[1]
            if fg.max()<g[j]: sk.append(it);
            else:
                al=place(fg,fc,k[j],g[j],c[j])
                if al is not None:
                    start[j]=t
                    for i,x in al: fg[i]-=x*g[j]; fc[i]-=x*c[j]
                    heapq.heappush(run,(t+p[j],j,al)); continue
                sk.append(it)
            if policy=='fcfs': break
            if guard is not None and (t-r[sk[0][1]])>guard: break  # starvation guard: stop backfilling behind an old head
            if len(sk)>300 or fg.max()<1: break
        for it in sk: heapq.heappush(Q,it)
    return r,p,k*g,start

def report(name,r,p,a_k,start):
    w=(start-r)/3600; a=a_k*p
    return dict(policy=name,mean_h=w.mean(),median_h=np.median(w),p95_h=np.percentile(w,95),p99_h=np.percentile(w,99),max_h=w.max(),
                areaW_h=(a*w).sum()/a.sum(),zero=(w<1/60).mean(),bsld=np.mean((w*3600+np.maximum(p,10))/np.maximum(p,10)))

if __name__=='__main__':
    m=sys.argv[1]
    d=J[J.gpu_model==m]; nn=N[N.gpu_model==m]
    capg=nn.gpu_capacity_num.values.astype(float); capc=nn.cpu_num.values.astype(float)
    for spec in sys.argv[2:]:
        pol,mode,*gd=spec.split(':'); guard=float(gd[0])*3600 if gd else None
        t0=time.time(); r,p,ak,st=simulate(d,capg,capc,pol,mode,guard)
        if np.isnan(st).any(): print(spec,'unfinished',int(np.isnan(st).sum()),flush=True); continue
        o=report(spec,r,p,ak,st); o['sec']=time.time()-t0
        print(m,' '.join(f'{a}={b:.4g}' if not isinstance(b,str) else f'{a}={b}' for a,b in o.items()),flush=True)
