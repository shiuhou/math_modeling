# GS1 (heterogeneous nodes: 1/4/8 GPU, 192 vCPU): best-fit vs ratio-matched placement (prediction of ratio-interval theorem)
import numpy as np, sys, time
import sim_node as SN
d=SN.J[SN.J.gpu_model=='GPU-series-1']; nn=SN.N[SN.N.gpu_model=='GPU-series-1']
capg=nn.gpu_capacity_num.values.astype(float); capc=nn.cpu_num.values.astype(float)
print('GS1 node classes (gpu,cpu):count', nn.groupby(['gpu_capacity_num','cpu_num']).size().to_dict())
nodeRatio=capc/capg
base_place=SN.place
def ratio_place(fg,fc,k,g,c):
    fit=np.minimum(fg//g, np.where(c>0, np.floor(fc/c+1e-9), 10**6)).astype(int)
    if fit.sum()<k: return None
    rho=c/g if g>0 else 0
    idx=np.nonzero(fit)[0]
    # prefer node classes whose CPU/GPU ratio is the smallest one >= rho (comparative advantage), then larger, then smaller; within class most-loaded first
    gap=nodeRatio[idx]-rho
    cls=np.where(gap>=0, gap, 1e6-gap)
    o=idx[np.lexsort((fc[idx],fg[idx],cls))]
    al=[];need=k
    for i in o:
        x=min(fit[i],need); al.append((i,x)); need-=x
        if need==0: break
    return al
for pol in sys.argv[1:]:
    for nm,pl in [('best-fit',base_place),('ratio-matched',ratio_place)]:
        SN.place=pl; t0=time.time()
        r,p,ak,st=SN.simulate(d,capg,capc,pol,'node')
        o=SN.report(f'{pol}/{nm}',r,p,ak,st)
        print(' '.join(f'{a}={b:.4g}' if not isinstance(b,str) else f'{a}={b}' for a,b in o.items()),f'sec={time.time()-t0:.1f}',flush=True)
