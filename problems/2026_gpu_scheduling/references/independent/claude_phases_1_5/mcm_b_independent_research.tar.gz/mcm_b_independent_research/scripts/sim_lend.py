import pandas as pd, numpy as np, heapq, sys
from sim_id import report
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
d=J[J.gpu_model=='A10']; r=d.submit_time.values.astype(float); p=d.duration.values.astype(float); k=d.worker_num.values.astype(int); c=d.cpu_request.values
def sim(L,Rm=50,tau=3600.,cmax=16):
    n=len(r); order=np.argsort(r,kind='stable'); st=np.full(n,np.nan)
    free=2494; slots=8*L; Qm=[];Qe=[];run=[];ai=0
    while ai<n or Qm or Qe or run:
        ta=r[order[ai]] if ai<n else np.inf; te=run[0][0] if run else np.inf; t=min(ta,te)
        while run and run[0][0]<=t:
            e,kk,lent=heapq.heappop(run)
            if lent: slots+=kk
            else: free+=kk
        while ai<n and r[order[ai]]<=t:
            j=order[ai]; ai+=1; heapq.heappush(Qm if p[j]<=tau else Qe,(p[j],j))
        Rn=Rm if ai<n else 0
        for Q,res in ((Qm,0),(Qe,Rn)):
            sk=[]
            while Q and (free>res or slots>0):
                it=heapq.heappop(Q); j=it[1]
                if c[j]<=cmax and k[j]<=slots:   # prefer lent slots for cpu-light jobs (comparative advantage)
                    st[j]=t; slots-=k[j]; heapq.heappush(run,(t+p[j],k[j],True))
                elif k[j]<=free-res:
                    st[j]=t; free-=k[j]; heapq.heappush(run,(t+p[j],k[j],False))
                else:
                    sk.append(it)
                    if len(sk)>200: break
            for it in sk: heapq.heappush(Q,it)
    return st
for L in [int(x) for x in sys.argv[1:]]:
    st=sim(L); o=report(f'lend{L}',r,p,k,st)
    print(' '.join(f'{a}={b:.4g}' if not isinstance(b,str) else f'{a}={b}' for a,b in o.items()),flush=True)
