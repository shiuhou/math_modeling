# count lower bound for every pool: at time t, jobs in Z(t)={r<=t<r+p} that are not running must be waiting;
# running GPUs <= C  =>  #waiting >= min #jobs to delete from Z(t) so that remaining GPU sum <= C (delete largest G first)
import pandas as pd, numpy as np
from sortedcontainers import SortedList
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])
J['G']=(J.gpu_request*J.worker_num).astype(int)
for m,d in J.groupby('gpu_model'):
    C=int(N[N.gpu_model==m].gpu_capacity_num.sum()); r=d.submit_time.values; p=d.duration.values; G=d.G.values; n=len(d)
    ev=np.concatenate([r,r+p]); typ=np.concatenate([np.ones(n,int),-np.ones(n,int)]); jj=np.concatenate([np.arange(n),np.arange(n)])
    o=np.lexsort((-typ,ev))  # departures (-1) after arrivals at same t: irrelevant for integral (zero-length)
    S=SortedList(); tot=0; I=0.; prev=None; peak=0
    for e in o:
        t=ev[e]
        if prev is not None and t>prev and tot>C:
            # minimal deletions
            need=tot-C; cnt=0; acc=0
            for g in reversed(S):
                acc+=g; cnt+=1
                if acc>=need: break
            I+=cnt*(t-prev); peak=max(peak,cnt)
        if typ[e]==1: S.add(G[jj[e]]); tot+=G[jj[e]]
        else: S.remove(G[jj[e]]); tot-=G[jj[e]]
        prev=t
    print(f'{m:16s} count-LB: total >= {I/3600:12,.0f} job-h ; mean wait >= {I/n/3600:8.4f} h ; peak forced-waiting jobs {peak}')
