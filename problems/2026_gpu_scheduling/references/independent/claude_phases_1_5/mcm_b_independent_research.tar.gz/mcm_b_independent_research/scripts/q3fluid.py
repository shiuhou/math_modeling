import pandas as pd, numpy as np
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])
J['G']=J.gpu_request*J.worker_num; J['C']=J.cpu_request*J.worker_num
capG=N.groupby('gpu_model').gpu_capacity_num.sum(); capC=N.groupby('gpu_model').cpu_num.sum()
dt=60.; grid=np.arange(0,320*86400,dt)
def occ(d,col):
    s=d.submit_time.values; e=s+d.duration.values; g=d[col].values.astype(float)
    ev=np.concatenate([s,e]); w=np.concatenate([g,-g]); o=np.argsort(ev,kind='stable')
    t=ev[o]; c=np.cumsum(w[o]); idx=np.searchsorted(t,grid,side='right')-1
    return np.where(idx>=0,c[np.maximum(idx,0)],0.)
a=J[J.gpu_model=='A10']; OA=occ(a,'G'); W=(a.G*a.duration).sum()
def LB(Cap):
    x=(OA-Cap)*dt; B=0.; I=0.
    for v in x:
        B=max(B+v,0.); I+=B*dt
    return I/W/3600
def lindley(x):
    # vectorized Lindley via cumulative min trick
    S=np.cumsum(x); m=np.minimum.accumulate(np.minimum(S,0)); return S-m
def LBv(Cap):
    B=lindley((OA-Cap)*dt); return (B.sum()*dt)/W/3600, B.max()/2494/3600
sp={}
for h in ['A100-SXM4-80GB','A800-SXM4-80GB','H800','GPU-series-2']:
    d=J[J.gpu_model==h]; sg=np.maximum(capG[h]-occ(d,'G'),0); sc=np.maximum(capC[h]-occ(d,'C'),0); sp[h]=(sg,sc)
base=2494.
print('no substitution     LB areaW=%.1f h, peak backlog %.0f pool-h'%LBv(np.full_like(OA,base)))
for name,hosts in [('A100',['A100-SXM4-80GB']),('A100+A800+H800',['A100-SXM4-80GB','A800-SXM4-80GB','H800']),('all4',list(sp))]:
    for kappa in [0,8,16,24.2]:
        H=sum(np.minimum(sp[h][0], sp[h][1]/kappa if kappa>0 else np.inf) for h in hosts)
        print(f'{name:16s} kappa={kappa:5.1f}  mean usable spare {H[:90*1440].mean():6.0f}  LB areaW={LBv(base+H)[0]:7.1f} h  peak {LBv(base+H)[1]:6.0f} pool-h')
# guaranteed headroom: capacity minus running max of occupancy (static)
for h in sp:
    print(h,'min spare GPU over [0,90d]',sp[h][0][:90*1440].min(),' p5', np.percentile(sp[h][0][:90*1440],5))
