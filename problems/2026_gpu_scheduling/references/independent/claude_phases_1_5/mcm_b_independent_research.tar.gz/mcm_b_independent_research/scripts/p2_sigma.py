import numpy as np, pandas as pd
import p2_sim as S
# select the same 534 residents as constant-H greedy (longest-first among t=0, cpu<=16, 1 worker)
A=S.A; cand=A[(A.submit_time==0)&(A.cpu_request<=16)&(A.worker_num==1)].sort_values('duration',ascending=False)
sel=set(cand.job_name.values[:534]); mv=np.isin(S.jid,list(sel))
base=S.sim('hol','sjf'); wb=base-S.r
# rerun with moved jobs removed from A10 (they run on A100 immediately)
keep=~mv
for nm in ['r','p','k','jid']: setattr(S,nm,getattr(S,nm)[keep])
S.n=keep.sum(); S.A=S.A[keep].reset_index(drop=True)
st=S.sim('hol','sjf'); w=st-S.r
p_mv=A.duration.values[mv]; k_mv=A.worker_num.values[mv]
others_base=wb[keep]
dCount=(others_base-w).sum()/3600; dArea=((S.k*S.p)*(others_base-w)).sum()/3600
print(f'moved {mv.sum()} residents; others: mean wait {others_base.mean()/3600:.2f} -> {w.mean()/3600:.2f} h; count benefit {dCount:,.0f} job-h; area benefit {dArea/3600:,.0f} GPU-h*h')
print(f'moved jobs native wait (baseline): mean {wb[mv].mean()/3600:.3f} h, max {wb[mv].max()/3600:.3f} h; sum p_moved {p_mv.sum()/3600:,.0f} h')
s_count=1+dCount/(p_mv.sum()/3600 ) ; s_area=1+ (dArea/3600)/((k_mv*p_mv*p_mv).sum()/3600/3600)
print(f'break-even sigma (count-delay metric): {s_count:.3f} ; (area-weighted delay metric): {s_area:.3f}')
print(f'all-A10 mean completion delay at sigma=1: {(w.sum()+0)/3600/len(A):.2f} h vs baseline {wb.mean()/3600:.2f} h')
