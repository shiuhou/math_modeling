# Phase 4 checks (no parameter search). Each block prints one result line-group.
import sys, numpy as np, pandas as pd, warnings; warnings.filterwarnings('ignore')
JOB=__import__('os').environ.get('MCM_JOB_CSV',__import__('os').environ['MCM_JOB_CSV'])
NODE=__import__('os').environ.get('MCM_NODE_CSV',__import__('os').environ['MCM_NODE_CSV'])
J=pd.read_csv(JOB); N=pd.read_csv(NODE)
which=sys.argv[1]
A=J[J.gpu_model=='A10'].reset_index(drop=True); r=A.submit_time.values; p=A.duration.values; k=A.worker_num.values; M=2494; n=len(A)

if which=='truncated':
    # Theorem T: sum_j min(W_j,p_j) >= int q dt (=22.3179 h * n). Decompose actual mean wait.
    LB=22.3179
    for nm in ['sjfhol','sjfskip','sjfeasy']:
        st=np.load(f'p2_st_{nm}.npy'); W=st-r
        tr=np.minimum(W,p).sum()/n/3600; ex=np.maximum(W-p,0).sum()/n/3600
        print(f'{nm:8s} mean W {W.mean()/3600:6.2f} h = truncated part {tr:6.2f} h (>= LB {LB}) + excess (W-p)+ {ex:6.2f} h ; jobs with W>p: {(W>p).mean():.3f}; excess from p<=1h jobs {np.maximum(W-p,0)[p<=3600].sum()/n/3600:.2f} h, from p>30d {np.maximum(W-p,0)[p>30*86400].sum()/n/3600:.2f} h')

if which=='shape':
    # shape-strengthened instantaneous bounds: max(q_GPU, q_CPU, q_bigGPU, q_bigCPU), grid 60 s midpoint
    dt=60.
    for m,d in J.groupby('gpu_model'):
        nn=N[N.gpu_model==m]; CG=nn.gpu_capacity_num.sum(); CC=nn.cpu_num.sum(); nodes=len(nn)
        maxg=nn.gpu_capacity_num.max(); maxc=nn.cpu_num.max()
        rr=d.submit_time.values; ee=rr+d.duration.values
        G=(d.gpu_request*d.worker_num).values; Cc=(d.cpu_request*d.worker_num).values
        # "big" workers: >half of the largest node in GPU or CPU => at most one such worker per node
        bigw=((d.gpu_request>maxg/2)|(d.cpu_request>maxc/2)).values*d.worker_num.values
        grid=np.arange(dt/2,ee.max(),dt)
        o=np.argsort(rr); oe=np.argsort(ee)
        def alive_sum(w):
            cs=np.concatenate([[0],np.cumsum(w[o])]); ce=np.concatenate([[0],np.cumsum(w[oe])])
            return cs[np.searchsorted(rr[o],grid,side='right')]-ce[np.searchsorted(ee[oe],grid,side='right')]
        sG=alive_sum(G.astype(float)); sC=alive_sum(Cc.astype(float)); sB=alive_sum(bigw.astype(float))
        # lower bounds on #deleted jobs: deficit / largest single-job contribution (valid, crude) -- only to detect any positive gain
        def qlb(s,cap,w):
            need=np.maximum(s-cap,0); return np.ceil(need/max(w.max(),1)-1e-9)
        qg=qlb(sG,CG,G); qc=qlb(sC,CC,Cc); qb=qlb(sB,nodes,bigw)
        print(f'{m:16s} time with positive bound (min): GPU {np.sum(qg>0)*dt/60:9.0f}  CPU {np.sum(qc>0)*dt/60:7.0f}  big-worker {np.sum(qb>0)*dt/60:7.0f}  | CPU or big positive where GPU zero: {np.sum(((qc>0)|(qb>0))&(qg==0))*dt/60:.0f} min')

if which=='renewal':
    # prediction: h_k ~ F_R^{-1}(k/M), F_R(x)=sum_j k_j min(x,p_j)/sum_j k_j p_j  (equilibrium residual of busy machines)
    st=np.load('p2_st_sjfhol.npy'); e=st+p
    xs=np.logspace(0,7.5,4000); FR=np.array([(k*np.minimum(x,p)).sum() for x in xs])/(k*p).sum()
    # observed h_k (median over snapshots days 7-90) recomputed
    snaps=np.arange(7,90,0.25)*86400; K=[1,2,5,10,20,32,60,100,200,500]; H=[]
    for t in snaps:
        run=(st<=t)&(e>t); res=np.repeat(e[run]-t,k[run]); free=M-k[run].sum()
        res=np.sort(np.concatenate([np.zeros(max(free,0)),res])); H.append([res[kk-1] for kk in K])
    H=np.median(np.array(H),0)
    for kk,h in zip(K,H):
        pred=xs[np.searchsorted(FR,kk/M)]
        print(f'k={kk:4d}: predicted h_k {pred/3600:9.2f} h   observed median {h/3600:9.2f} h   ratio obs/pred {h/pred:6.2f}')
    # predicted deliberate-idle cost for gang starts under strict order: sum over multi-worker jobs of k*h_k/2
    g=k>1; hk=np.array([xs[np.searchsorted(FR,kk/M)] for kk in k[g]])
    print('predicted idle (sum k h_k /2) over all multi-worker A10 jobs:',f'{(k[g]*hk/2).sum()/3600:,.0f} machine-h ; observed (strict SPT, [0,90d]) 1,927 machine-h')

if which=='gs1cond':
    # sufficient condition for ratio-matched zero wait without spill: per-class zero-wait worker occupancy <= class capacity
    d=J[J.gpu_model=='GPU-series-1']; nn=N[N.gpu_model=='GPU-series-1']
    N8=(nn.gpu_capacity_num==8).sum(); N4=(nn.gpu_capacity_num==4).sum(); N1=(nn.gpu_capacity_num==1).sum()
    rr=d.submit_time.values; ee=rr+d.duration.values; c=d.cpu_request.values; g=d.gpu_request.values; w=d.worker_num.values
    cls=np.where(g>1,'multi',np.where(c<=24,'c8',np.where(c<=48,'c4','c1')))
    ev_t=np.concatenate([rr,ee]);
    for cl,cap in [('c8',8*N8),('c4',4*N4),('c1',N1),('multi',None)]:
        m=cls==cl
        if m.sum()==0: continue
        t=np.concatenate([rr[m],ee[m]]); dw=np.concatenate([w[m],-w[m]]); o=np.lexsort((dw,t)); occ=np.cumsum(dw[o])  # departures first at ties
        print(f'class {cl:5s}: jobs {m.sum():5d}, workers {w[m].sum():6d}, max zero-wait worker occupancy {occ.max():5d}  vs own-type slots {cap}')
    print(f'node counts N8={N8} N4={N4} N1={N1} (incl. one 1-GPU/128-CPU node)')

if which=='a100lend':
    import sim_node as SN
    d=J[J.gpu_model=='A100-SXM4-80GB']
    for L in [67]:
        capg=np.full(432-L,8.); capc=np.full(432-L,128.)
        for pol in ['fcfs','sjf']:
            rr,pp,ak,st=SN.simulate(d,capg,capc,pol,'node'); w=(st-rr)/3600
            print(f'A100 natives on {432-L} nodes ({pol}, best-fit): mean {w.mean():.5f} h, max {w.max():.3f} h, zero-wait {np.mean(w<=0):.5f}')
