import pandas as pd, numpy as np, heapq, sys, time
from sim_id import report
def sim_trunk(r,p,k,M,R,tau,ekey='sjf'):
    # mice: p<=tau, SJF greedy; elephants: may start only if free-k>=R (trunk reservation)
    n=len(r); order=np.argsort(r,kind='stable'); start=np.full(n,np.nan)
    Qm=[];Qe=[];run=[];free=M;ai=0
    while ai<n or Qm or Qe or run:
        ta=r[order[ai]] if ai<n else np.inf; te=run[0][0] if run else np.inf; t=min(ta,te)
        while run and run[0][0]<=t: e,kk=heapq.heappop(run); free+=kk
        while ai<n and r[order[ai]]<=t:
            j=order[ai]; ai+=1
            if p[j]<=tau: heapq.heappush(Qm,(p[j],j))
            else: heapq.heappush(Qe,((p[j] if ekey=='sjf' else r[j]),j))
        Rnow=R if ai<n else 0   # release reserve once arrivals stop
        for Q,res in ((Qm,0),(Qe,Rnow)):
            sk=[]
            while Q and free>res:
                it=heapq.heappop(Q); j=it[1]
                if k[j]<=free-res: start[j]=t; free-=k[j]; heapq.heappush(run,(t+p[j],k[j]))
                else:
                    sk.append(it)
                    if len(sk)>200: break
            for it in sk: heapq.heappush(Q,it)
    return start
if __name__=='__main__':
    J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
    d=J[J.gpu_model=='A10']; r=d.submit_time.values.astype(float); p=d.duration.values.astype(float); k=d.worker_num.values.astype(int)
    for spec in sys.argv[1:]:
        R,tau,ek=spec.split(':'); t0=time.time()
        st=sim_trunk(r,p,k,2494,int(R),float(tau),ek)
        if np.isnan(st).any(): print(spec,'unfinished',np.isnan(st).sum()); continue
        o=report(spec,r,p,k,st)
        mice=p<=float(tau); w=(st-r)/3600
        o['mice_frac']=mice.mean(); o['mice_p95_h']=np.percentile(w[mice],95); o['mice_p99_h']=np.percentile(w[mice],99); o['mice_max_h']=w[mice].max()
        o['eleph_mean_h']=w[~mice].mean(); o['sec']=time.time()-t0
        print(' '.join(f'{a}={b:.4g}' if not isinstance(b,str) else f'{a}={b}' for a,b in o.items()),flush=True)
