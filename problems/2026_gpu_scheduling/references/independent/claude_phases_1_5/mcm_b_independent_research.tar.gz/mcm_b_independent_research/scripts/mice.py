import pandas as pd, numpy as np
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
d=J[J.gpu_model=='A10']
for tau in [3600,86400]:
    m=d[d.duration<=tau]; r=m.submit_time.values; p=m.duration.values; k=m.worker_num.values
    T=90*86400; rho=(k*p).sum()/T
    ev=np.concatenate([r,r+p]); w=np.concatenate([k,-k]); o=np.argsort(ev,kind='stable'); t=ev[o]; occ=np.cumsum(w[o])
    dur=np.diff(t); occ=occ[:-1]; msk=t[:-1]<T
    vals=occ[msk]; wts=dur[msk]
    oo=np.argsort(vals); cw=np.cumsum(wts[oo])/wts[msk.sum() and slice(None)].sum() if False else np.cumsum(wts[oo])/wts.sum()
    q=lambda x: vals[oo][np.searchsorted(cw,x)]
    # hourly counts dispersion of mice arrivals
    hc=np.bincount((r//3600).astype(int),minlength=2160)[:2160]
    I=hc.var()/hc.mean()
    print(f'tau={tau}: jobs {len(m)} ({len(m)/len(d):.1%}), offered load rho_m={rho:.2f} nodes, time-avg occupancy quantiles: q99={q(.99)} q999={q(.999)} q9999={q(.9999)} max={vals.max()}, Poisson R(1e-3)=rho+3.09sqrt(rho)={rho+3.09*np.sqrt(rho):.1f}, dispersion I={I:.1f} -> rho+3.09sqrt(I rho)={rho+3.09*np.sqrt(I*rho):.1f}')
