import pandas as pd, numpy as np
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])
print(J.shape, N.shape); print(J.describe().T)
print(J.isna().sum().sum(), J.job_name.nunique())
N['cpu_per_gpu']=N.cpu_num/N.gpu_capacity_num
print(N.groupby(['gpu_model','gpu_capacity_num','cpu_num']).size())
cap=N.groupby('gpu_model').agg(nodes=('node_name','size'),gpus=('gpu_capacity_num','sum'),cpus=('cpu_num','sum'))
print(cap)
J['G']=J.gpu_request*J.worker_num; J['C']=J.cpu_request*J.worker_num
J['gh']=J.G*J.duration/3600; J['ch']=J.C*J.duration/3600
T=J.submit_time.max(); print('T days',T/86400, 'min',J.submit_time.min())
end=(J.submit_time+J.duration).max(); print('max end days', end/86400)
g=J.groupby('gpu_model').agg(n=('job_name','size'),gh=('gh','sum'),ch=('ch','sum'),
   maxG=('G','max'),maxW=('worker_num','max'),maxg=('gpu_request','max'),maxc=('cpu_request','max'))
g=g.join(cap)
g['rho_gpu']=g.gh/(g.gpus*T/3600); g['rho_cpu']=g.ch/(g.cpus*T/3600)
pd.set_option('display.width',250); print(g)
print(J.gpu_model.value_counts())
