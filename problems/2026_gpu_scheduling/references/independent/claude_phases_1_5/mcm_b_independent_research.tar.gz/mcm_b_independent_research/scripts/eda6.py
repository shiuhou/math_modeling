import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_columns',30)
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])
J['G']=J.gpu_request*J.worker_num; J['C']=J.cpu_request*J.worker_num; J['gh']=J.G*J.duration/3600
capG=N.groupby('gpu_model').gpu_capacity_num.sum(); capC=N.groupby('gpu_model').cpu_num.sum()
H=np.arange(0,90*24)*3600.
def occ(d,col):
    s=d.submit_time.values; e=s+d.duration.values; g=d[col].values
    ev=np.concatenate([s,e]); w=np.concatenate([g,-g]); o=np.argsort(ev,kind='stable')
    t=ev[o]; c=np.cumsum(w[o]); idx=np.searchsorted(t,H,side='right')-1
    return np.where(idx>=0,c[np.maximum(idx,0)],0)
a=J[J.gpu_model=='A10']
for lo,hi in [(0,8),(8,16),(16,24),(24,32),(32,64),(64,129)]:
    m=(a.cpu_request>lo)&(a.cpu_request<=hi)
    print(f'A10 cpu in ({lo},{hi}]: jobs {m.mean()*100:.1f}%  GPUh {a.gh[m].sum()/a.gh.sum()*100:.1f}%')
print()
tot_sg=0
for mdl in ['A100-SXM4-80GB','A800-SXM4-80GB','H800','GPU-series-2','GPU-series-1']:
    d=J[J.gpu_model==mdl]
    og=occ(d,'G'); oc=occ(d,'C')
    sg=capG[mdl]-og; sc=capC[mdl]-oc
    print(f'{mdl:16s} spare GPU mean {sg.mean():7.0f} p10 {np.percentile(sg,10):7.0f}  spare CPU mean {sc.mean():8.0f}  cpu/gpu of spare {sc.mean()/max(sg.mean(),1):.1f}  CPU util {oc.mean()/capC[mdl]:.2f} GPU util {og.mean()/capG[mdl]:.2f}')
ea=occ(a,'G')-capG['A10']; eac=occ(a,'C')
print('A10 excess GPU mean',ea.mean(),'p90',np.percentile(ea,90),' A10 CPU zero-wait util',eac.mean()/capC['A10'])
# arrivals time structure
J['day']=(J.submit_time//86400).astype(int); J['hod']=((J.submit_time%86400)//3600).astype(int); J['dow']=J.day%7
x=J[J.submit_time>0]
print('daily arrivals: mean',x.groupby('day').size().mean(),'cv',x.groupby('day').size().std()/x.groupby('day').size().mean())
print('hour-of-day profile (rel):',(x.groupby('hod').size()/x.groupby('hod').size().mean()).round(2).tolist())
print('dow profile (rel):',(x.groupby('dow').size()/x.groupby('dow').size().mean()).round(2).tolist())
# daily GPU-hour demand per model cv
dd=x.groupby(['day','gpu_model']).gh.sum().unstack().fillna(0)
print('daily GPUh demand cv by model', (dd.std()/dd.mean()).round(2).to_dict())
# hourly arrival counts dispersion index
hc=x.groupby(x.submit_time//3600).size().reindex(range(1,90*24),fill_value=0)
print('hourly arrival index of dispersion', hc.var()/hc.mean())
# inter-arrival same-shape bursts: fraction of jobs with an identical (model,cpu,gpu,worker,duration) job within 60s
x=x.sort_values('submit_time')
key=x[['gpu_model','cpu_request','gpu_request','worker_num']].astype(str).agg('|'.join,axis=1)
x['key']=key; x['prev']=x.groupby('key').submit_time.diff()
print('frac jobs w/ same-shape predecessor within 60s', (x.prev<=60).mean(), ' within 10min', (x.prev<=600).mean())
