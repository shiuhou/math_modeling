# Erratum 3: shape-strengthened count bound, exact over ALL event intervals.
# Separate constraints on the in-service subset R of Z(t):
#   (G) sum GPU <= C_G   (C) sum CPU <= C_C
#   (GH) #GPU-heavy workers (g > maxg/2) <= #nodes   -- two such workers can never share a node
#   (CH) #CPU-heavy workers (c > maxc/2) <= #nodes   -- likewise; GH and CH are NOT merged
# (The Phase-4 script merged GH and CH into one count: invalid, since e.g. (5 GPU,1 CPU) and (1 GPU,65 CPU) share an 8 GPU/128 CPU node.)
# q_X = min #jobs to delete so constraint X holds (greedy, largest contribution first, exact for one constraint).
# Valid bound: q*(t) = max(q_G,q_C,q_GH,q_CH). Gain over q_G is integrated exactly on every interval where some secondary deficit > 0.
import os, numpy as np, pandas as pd
J=pd.read_csv(os.environ['MCM_JOB_CSV']); N=pd.read_csv(os.environ['MCM_NODE_CSV'])
def greedy(vals,need):
    if need<=0: return 0
    s=np.sort(vals[vals>0])[::-1]; c=np.cumsum(s); return int(np.searchsorted(c,need-1e-9)+1)
for m,d in J.groupby('gpu_model'):
    nn=N[N.gpu_model==m]; CG=nn.gpu_capacity_num.sum(); CC=nn.cpu_num.sum(); nodes=len(nn)
    maxg=nn.gpu_capacity_num.max(); maxc=nn.cpu_num.max()
    r=d.submit_time.values.astype(float); e=r+d.duration.values; k=d.worker_num.values
    vG=(d.gpu_request.values*k).astype(float); vC=(d.cpu_request.values*k).astype(float)
    vGH=((d.gpu_request.values>maxg/2)*k).astype(float); vCH=((d.cpu_request.values>maxc/2)*k).astype(float)
    t=np.unique(np.concatenate([r,e])); L=np.diff(t); t0=t[:-1]
    o=np.argsort(r); oe=np.argsort(e)
    def alive(v):
        cs=np.concatenate([[0],np.cumsum(v[o])]); ce=np.concatenate([[0],np.cumsum(v[oe])])
        return cs[np.searchsorted(r[o],t0,side='right')]-ce[np.searchsorted(e[oe],t0,side='right')]
    dG=alive(vG)-CG; dC=alive(vC)-CC; dGH=alive(vGH)-nodes; dCH=alive(vCH)-nodes
    same_GH=bool(np.all(vGH==vG))   # A10: every worker is 1-GPU on 1-GPU nodes -> GH identical to G
    sec=(dC>1e-9)|((dGH>0)&(not same_GH))|(dCH>0)
    gain=0.; idx=np.nonzero(sec)[0]; worst=0
    for i in idx:
        al=(r<=t0[i])&(e>t0[i])
        qG=greedy(vG[al],dG[i]); q=max(qG,greedy(vC[al],dC[i]),0 if same_GH else greedy(vGH[al],dGH[i]),greedy(vCH[al],dCH[i]))
        gain+=(q-qG)*L[i]; worst=max(worst,q-qG)
    print(f'{m:16s} intervals {len(L):7d} | with dG>0 {int((dG>0).sum()):6d} dC>0 {int((dC>1e-9).sum()):5d} dGH>0 {int((dGH>0).sum()):6d}{" (identical to G)" if same_GH else ""} dCH>0 {int((dCH>0).sum()):5d}'
          f' | secondary intervals checked {len(idx)} | exact extra integral {gain!r} job*s ({gain/len(d)/3600!r} h per job), max pointwise gain {worst}')
