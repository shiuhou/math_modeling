# Errata 3 and 4: exhaustive checks of two hand counterexamples (no data needed).
import itertools
def feasible(nodes,workers):
    # exhaustive assignment of workers (g,c) to nodes (G,C)
    for asg in itertools.product(range(len(nodes)),repeat=len(workers)):
        ok=all(sum(w[0] for w,a in zip(workers,asg) if a==i)<=nodes[i][0] and sum(w[1] for w,a in zip(workers,asg) if a==i)<=nodes[i][1] for i in range(len(nodes)))
        if ok: return asg
    return None
# A4: a merged "heavy worker" count is invalid
print('A4: one 8 GPU/128 CPU node, workers (5 GPU,1 CPU) and (1 GPU,65 CPU): feasible assignment =',feasible([(8,128)],[(5,1),(1,65)]),
      '-> merged heavy count 2 > 1 node would wrongly force a deletion; separate counts give GH=1<=1, CH=1<=1')
# A8: zero wait is NOT equivalent to O0<=C even with no downward placement
nodes=[(8,8),(1,16)]; jobs=[(1,16),(1,16)]
print('A8: nodes',nodes,'jobs',jobs,'| total GPU demand',sum(j[0] for j in jobs),'<= C =',sum(n[0] for n in nodes),
      '| simultaneous feasible assignment =',feasible(nodes,jobs),'-> some job must wait under ANY policy')
print('    node CPU/GPU ratios',[c/g for g,c in nodes],' job ratio',16.0,': only node 2 is compatible; the 8 GPUs of node 1 are unusable for these jobs')
