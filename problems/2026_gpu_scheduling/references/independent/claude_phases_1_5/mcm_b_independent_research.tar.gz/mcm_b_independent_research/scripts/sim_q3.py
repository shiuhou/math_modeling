# joint A10 + host pools, node-level hosts, A10 overflow with trunk reservation on hosts
import pandas as pd, numpy as np, heapq, sys, time
from sim_node import place
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])

def run(hosts, Rh, cpu_rule, sigma=1.0, Rm=50, tau=3600., mode='coloc', maxdur=np.inf):
    pools=['A10']+hosts
    d=J[J.gpu_model.isin(pools)].reset_index(drop=True)
    pid=d.gpu_model.map({m:i for i,m in enumerate(pools)}).values
    r=d.submit_time.values.astype(float); p=d.duration.values.astype(float)
    k=d.worker_num.values.astype(int); g=d.gpu_request.values.astype(float); c=d.cpu_request.values.astype(float)
    n=len(r); order=np.argsort(r,kind='stable'); start=np.full(n,np.nan); where=np.full(n,-1)
    freeA=2494
    FG=[];FC=[];LENT=[]
    for h in hosts:
        nn=N[N.gpu_model==h]; FG.append(nn.gpu_capacity_num.values.astype(float)); FC.append(nn.cpu_num.values.astype(float)); LENT.append(np.zeros(len(nn),bool))
    CAPG=[x.copy() for x in FG]
    Qm=[];Qe=[];QH=[[] for _ in hosts]; run=[]; ai=0
    def start_host(j,hi,al,t,dur):
        start[j]=t; where[j]=hi+1
        for i,x in al: FG[hi][i]-=x*g[j]; FC[hi][i]-=x*c[j]
        heapq.heappush(run,(t+dur,j,hi,al))
    while ai<n or Qm or Qe or run or any(QH):
        ta=r[order[ai]] if ai<n else np.inf; te=run[0][0] if run else np.inf; t=min(ta,te)
        while run and run[0][0]<=t:
            e,j,hi,al=heapq.heappop(run)
            if hi<0: freeA+=k[j]
            else:
                for i,x in al: FG[hi][i]+=x*g[j]; FC[hi][i]+=x*c[j]
        while ai<n and r[order[ai]]<=t:
            j=order[ai]; ai+=1
            if pid[j]==0:
                if p[j]<=tau: heapq.heappush(Qm,(p[j],j))
                else: heapq.heappush(Qe,(p[j],j))
            else: heapq.heappush(QH[pid[j]-1],(p[j],j))
        # hosts own jobs first (greedy SJF)
        for hi in range(len(hosts)):
            Q=QH[hi]; sk=[]
            while Q:
                it=heapq.heappop(Q); j=it[1]
                al=place(FG[hi],FC[hi],k[j],g[j],c[j]) if FG[hi].max()>=g[j] else None
                if al is None:
                    sk.append(it)
                    if len(sk)>100: break
                    continue
                start_host(j,hi,al,t,p[j])
            for it in sk: heapq.heappush(Q,it)
        # A10 native: mice lane + elephants with trunk reserve
        Rnow=Rm if ai<n else 0
        for Q,res in ((Qm,0),(Qe,Rnow)):
            sk=[]
            while Q and freeA>res:
                it=heapq.heappop(Q); j=it[1]
                if k[j]<=freeA-res:
                    start[j]=t; where[j]=0; freeA-=k[j]; heapq.heappush(run,(t+p[j],j,-1,None))
                else:
                    sk.append(it)
                    if len(sk)>200: break
            for it in sk: heapq.heappush(Q,it)
        # overflow of waiting A10 jobs to hosts
        for hi in range(len(hosts)):
            if QH[hi]: continue
            sk=[]; tries=0
            while Qe and (mode=='empty' or FG[hi].sum()>Rh[hi]) and tries<400:
                it=heapq.heappop(Qe); j=it[1]; tries+=1
                if mode=='empty':
                    if c[j]>cpu_rule[hi] or p[j]>maxdur: sk.append(it); continue
                elif c[j]>cpu_rule[hi] or p[j]>maxdur or FG[hi].sum()-k[j]<Rh[hi]: sk.append(it); continue
                if mode=='lend':
                    ok=LENT[hi]|(FG[hi]==FG[hi].max()) # lent nodes or fully empty nodes
                    fg=np.where(ok,FG[hi],0.); al=place(fg,FC[hi],k[j],1.0,c[j])
                    if al is not None:
                        for i,x in al: LENT[hi][i]=True
                elif mode=='empty':
                    full=FG[hi]==CAPG[hi]
                    al=place(np.where(full,0.,FG[hi]),FC[hi],k[j],1.0,c[j])   # only onto already-used nodes
                    if al is None and full.sum()-1>=Rh[hi]:
                        al=place(FG[hi],FC[hi],k[j],1.0,c[j])
                else: al=place(FG[hi],FC[hi],k[j],1.0,c[j])
                if al is None: sk.append(it); continue
                start_host(j,hi,al,t,p[j]*sigma)
            for it in sk: heapq.heappush(Qe,it)
        if mode=='lend':
            for hi in range(len(hosts)):
                LENT[hi]&=~(FG[hi]==N[N.gpu_model==hosts[hi]].gpu_capacity_num.values)  # release when empty
    w=(start-r)/3600; out={}
    A=pid==0; a=k*g*p
    out['A10_mean']=w[A].mean(); out['A10_med']=np.median(w[A]); out['A10_p95']=np.percentile(w[A],95); out['A10_p99']=np.percentile(w[A],99)
    out['A10_max_d']=w[A].max()/24; out['A10_areaW']=(a[A]*w[A]).sum()/a[A].sum()
    out['moved_jobs']=int((A&(where>0)).sum()); out['moved_GPUh_share']=(a[A&(where>0)]).sum()/a[A].sum()
    for hi,h in enumerate(hosts):
        Hm=pid==hi+1
        out[h[:4]+'_mean']=w[Hm].mean(); out[h[:4]+'_p99']=np.percentile(w[Hm],99); out[h[:4]+'_max']=w[Hm].max(); out[h[:4]+'_zero']=(w[Hm]<1/60).mean()
    return out

if __name__=='__main__':
    for spec in sys.argv[1:]:
        # hosts|R1,R2|cpu1,cpu2|mode|sigma
        f=spec.split('|'); hs,Rs,cs,mode,sg=f[:5]; md=float(f[5])*3600 if len(f)>5 else np.inf; hosts=hs.split(',')
        t0=time.time(); o=run(hosts,[float(x) for x in Rs.split(',')],[float(x) for x in cs.split(',')],float(sg),mode=mode,maxdur=md)
        o['sec']=time.time()-t0
        print(spec,' '.join(f'{a}={b:.4g}' for a,b in o.items()),flush=True)
