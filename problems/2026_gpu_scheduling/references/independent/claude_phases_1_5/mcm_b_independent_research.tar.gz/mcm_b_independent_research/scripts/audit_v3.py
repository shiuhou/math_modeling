# Audit V3: GS1 fair comparison of legal placement rules under FCFS-strict (same arrivals, same sequencing)
import numpy as np, heapq, sys, warnings; warnings.filterwarnings('ignore')
import sim_node as SN
d=SN.J[SN.J.gpu_model=='GPU-series-1']; nn=SN.N[SN.N.gpu_model=='GPU-series-1'].reset_index(drop=True)
capg=nn.gpu_capacity_num.values.astype(float); capc=nn.cpu_num.values.astype(float); ratio=capc/capg
print('GS1 jobs',len(d),'unique ids',d.job_name.nunique(),' workers>1:',(d.worker_num>1).sum(),' max workers',d.worker_num.max(),
      ' gpu_request values',sorted(d.gpu_request.unique()),' cpu/worker range',d.cpu_request.min(),d.cpu_request.max())
print('  workers with cpu>24 (cannot share an 8-GPU node without stranding):',int(((d.cpu_request>24)*d.worker_num).sum()),'of',int(d.worker_num.sum()))
def fitv(fg,fc,g,c):
    return np.minimum(fg//g, np.where(c>0, np.floor(fc/np.where(c>0,c,1)+1e-9), 10**6)).astype(int)
def static_ff(order):
    def pl(fg,fc,k,g,c):
        f=fitv(fg,fc,g,c)
        if f.sum()<k: return None
        al=[];need=k
        for i in order:
            if f[i]>0:
                x=min(f[i],need); al.append((i,x)); need-=x
                if need==0: break
        return al
    return pl
def ratio_matched(fg,fc,k,g,c):
    f=fitv(fg,fc,g,c)
    if f.sum()<k: return None
    rho=c/g; idx=np.nonzero(f)[0]; gap=ratio[idx]-rho; cls=np.where(gap>=0,gap,1e6-gap)
    o=idx[np.lexsort((fc[idx],fg[idx],cls))]; al=[];need=k
    for i in o:
        x=min(f[i],need); al.append((i,x)); need-=x
        if need==0: break
    return al
name=nn.node_name.values
rules={'FF node_name order':static_ff(np.argsort(name,kind='stable')),
       'FF small nodes first':static_ff(np.lexsort((name,capg))),
       'FF large nodes first':static_ff(np.lexsort((name,-capg))),
       'best-fit (most loaded)':SN.place,
       'ratio-matched':ratio_matched}
rng=np.random.default_rng(2026)
for s in range(3): rules[f'FF random order #{s}']=static_ff(rng.permutation(len(capg)))
for nm,pl in rules.items():
    SN.place=pl; r,p,ak,st=SN.simulate(d,capg,capc,'fcfs','node'); w=(st-r)/3600
    print(f'{nm:24s} mean {w.mean():7.3f} h | p99 {np.percentile(w,99):7.2f} | max {w.max():7.2f} | zero-wait {np.mean(w<=0):.4f}',flush=True)
