# identical-machine pool simulator (each worker = 1 machine), non-preemptive gang
import pandas as pd, numpy as np, heapq, sys, time
from sortedcontainers import SortedList
def simulate(r,p,k,M,policy,reserve=0,tau=None,S=None):
    n=len(r); order=np.lexsort((np.arange(n),r))
    start=np.full(n,np.nan)
    if policy in('fcfs','easy','gfcfs'): key=lambda j:(r[j],j)
    elif policy=='sjf': key=lambda j:(p[j],r[j],j)
    elif policy=='saf': key=lambda j:(p[j]*k[j],r[j],j)
    elif policy=='stretch': key=lambda j:(r[j]+S*p[j],j)
    Q=[]; free=M; run=[]  # heap of (end,k)
    ends=SortedList()
    ai=0; t=0.
    def startjob(j,t):
        nonlocal free
        start[j]=t; free-=k[j]; heapq.heappush(run,(t+p[j],k[j])); ends.add((t+p[j],k[j]))
    while ai<n or Q or run:
        # next event
        ta=r[order[ai]] if ai<n else np.inf; te=run[0][0] if run else np.inf
        t=min(ta,te)
        while run and run[0][0]<=t:
            e,kk=heapq.heappop(run); free+=kk; ends.remove((e,kk))
        while ai<n and r[order[ai]]<=t:
            j=order[ai]; heapq.heappush(Q,(key(j),j)); ai+=1
        if not Q or free==0: continue
        if policy=='fcfs':
            while Q and k[Q[0][1]]<=free: _,j=heapq.heappop(Q); startjob(j,t)
        elif policy=='easy':
            while Q and k[Q[0][1]]<=free: _,j=heapq.heappop(Q); startjob(j,t)
            if Q and free>0:
                h=Q[0][1]; need=k[h]-free; acc=0
                for (e,kk) in ends:
                    acc+=kk
                    if acc>=need: shadow=e; extra=acc-need; break
                # backfill scan in FCFS order (limit scan)
                skipped=[heapq.heappop(Q)]
                cnt=0
                while Q and free>0 and cnt<5000:
                    it=heapq.heappop(Q); j=it[1]; cnt+=1
                    if k[j]<=free and (t+p[j]<=shadow or k[j]<=extra):
                        if not(t+p[j]<=shadow): extra-=k[j]
                        startjob(j,t)
                    else: skipped.append(it)
                for it in skipped: heapq.heappush(Q,it)
        else: # greedy list scheduling with optional mice reservation
            skipped=[]
            while Q and free>0:
                it=heapq.heappop(Q); j=it[1]
                ok=k[j]<=free
                if ok and reserve>0 and p[j]>tau and free-k[j]<reserve: ok=False
                if ok: startjob(j,t)
                else:
                    skipped.append(it)
                    if len(skipped)>3000: break
            for it in skipped: heapq.heappush(Q,it)
    return start
def report(name,r,p,k,start,LBh=None):
    w=(start-r)/3600; a=k*p
    out=dict(policy=name,mean_h=w.mean(),median_h=np.median(w),p95_h=np.percentile(w,95),p99_h=np.percentile(w,99),max_d=w.max()/24,
             areaW_h=(a*w).sum()/a.sum(),zero_wait=(w<1/60).mean(),
             mean_bsld=np.mean((w*3600+np.maximum(p,10))/np.maximum(p,10)),makespan_d=(start+p).max()/86400)
    return out
if __name__=='__main__':
    J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
    m=sys.argv[1]; M=int(sys.argv[2]); pols=sys.argv[3].split(',')
    d=J[J.gpu_model==m]
    r=d.submit_time.values.astype(float); p=d.duration.values.astype(float)
    k=(d.worker_num*d.gpu_request//(1 if m=='A10' else 8)).values.astype(int) if m=='A10' else d.worker_num.values.astype(int)
    rows=[]
    for pol in pols:
        t0=time.time()
        if pol.startswith('res'):
            _,R,tau=pol.split(':'); st=simulate(r,p,k,M,'sjf',reserve=int(R),tau=float(tau))
        elif pol.startswith('resf'):
            pass
        elif pol.startswith('stretch'):
            S=float(pol.split(':')[1]); st=simulate(r,p,k,M,'stretch',S=S)
        else: st=simulate(r,p,k,M,pol)
        o=report(pol,r,p,k,st); o['sec']=time.time()-t0; rows.append(o); print(o,flush=True)
    pd.DataFrame(rows).to_csv(f'res_{m}.csv',mode='a',index=False)
