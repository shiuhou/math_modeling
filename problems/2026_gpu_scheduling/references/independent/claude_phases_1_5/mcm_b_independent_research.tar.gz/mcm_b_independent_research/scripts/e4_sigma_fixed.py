# Erratum 5: Q3 break-even slowdown on a FIXED original population (all 111,284 A10 jobs) with FIXED native weights.
# Configuration: L=60 dedicated A100 nodes (8 slots x 128 vCPU) host the 480 longest A10 jobs of the initial submission batch
# (submit_time==0, worker_num==1, cpu_request<=16). Policy on A10 before and after: SPT-strict (p2_sim.sim('hol','sjf')).
# Moved job j starts on the host at r_j=0 and runs sigma*p_j  =>  delay delta_j = (sigma-1) p_j  (native p_j as reference).
import os, numpy as np, heapq
from sortedcontainers import SortedList
import p2_sim as S
A=S.A.copy(); r0=S.r.copy(); p0=S.p.copy(); k0=S.k.copy(); jid0=S.jid.copy(); n0=len(A)
cand=A[(A.submit_time==0)&(A.cpu_request<=16)&(A.worker_num==1)].sort_values('duration',ascending=False)
mv=np.isin(jid0,cand.job_name.values[:480])
assert mv.sum()==480 and (k0[mv]==1).all() and (A.cpu_request.values[mv]<=16).all() and (r0[mv]==0).all()
base=S.sim('hol','sjf'); d0=base-r0
print('prerequisite: native delay of moved jobs under SPT-strict = 0 for all:',bool(np.all(d0[mv]==0)),'| slots at t=0: 480 jobs <= 8*60 = 480')
keep=~mv
for nm,v in [('r',r0),('p',p0),('k',k0),('jid',jid0)]: setattr(S,nm,v[keep])
S.n=int(keep.sum()); S.A=A[keep].reset_index(drop=True)
d1=S.sim('hol','sjf')-S.r
a0=k0*p0                       # native GPU-area weights (GPU*s)
before_cnt=d0.sum(); after_rem_cnt=d1.sum(); sum_p=p0[mv].sum()
before_area=(a0*d0).sum(); after_rem_area=(a0[keep]*d1).sum(); sum_ap=(a0[mv]*p0[mv]).sum()
dB=before_cnt-after_rem_cnt; dBa=before_area-after_rem_area
print(f'population n={n0} (fixed); moved={int(mv.sum())}; remaining={int(keep.sum())}')
print(f'count: sum delta before = {before_cnt!r} s ; after (remaining, sigma-free) = {after_rem_cnt!r} s ; Delta_B = {dB!r} s ; sum p_moved = {sum_p!r} s')
print(f'       sigma*_count = 1 + Delta_B/sum p_moved = {1+dB/sum_p!r}')
print(f'       fixed-denominator mean delay: before {before_cnt/n0/3600!r} h ; after(sigma) = {after_rem_cnt/n0/3600!r} + (sigma-1)*{sum_p/n0/3600!r} h')
print(f'area : sum a*delta before = {before_area!r} ; after remaining = {after_rem_area!r} ; Delta_B_a = {dBa!r} ; sum a_j p_j (moved) = {sum_ap!r}  [GPU*s^2]')
print(f'       sigma*_area = {1+dBa/sum_ap!r}')
print(f'(for comparison, remaining-jobs-only mean wait: {d0[keep].mean()/3600!r} -> {d1.mean()/3600!r} h)')
# count LB of the remaining jobs, normalised by the fixed n0 (moved jobs contribute their own delay separately)
r,p,G=S.r,S.p,S.k.astype(float)
ev=np.concatenate([r,r+p]); typ=np.concatenate([np.ones(len(r),int),-np.ones(len(r),int)]); jj=np.concatenate([np.arange(len(r))]*2)
o=np.lexsort((-typ,ev)); SL=SortedList(); tot=0.; I=0.; prev=None
for e in o:
    t=ev[e]
    if prev is not None and t>prev and tot>2494:
        need=tot-2494; acc=0; cnt=0
        for g in reversed(SL):
            acc+=g; cnt+=1
            if acc>=need: break
        I+=cnt*(t-prev)
    if typ[e]==1: SL.add(G[jj[e]]); tot+=G[jj[e]]
    else: SL.remove(G[jj[e]]); tot-=G[jj[e]]
    prev=t
print(f'count LB of remaining jobs: {I!r} job*s ; normalised by fixed n0 = {I/n0/3600!r} h (moved jobs then add (sigma-1)*{sum_p/n0/3600!r} h)')
