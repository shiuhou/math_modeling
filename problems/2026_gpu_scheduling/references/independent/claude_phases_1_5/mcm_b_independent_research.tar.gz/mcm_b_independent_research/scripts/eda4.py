import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_columns',30)
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
J['end']=J.submit_time+J.duration
J['G']=J.gpu_request*J.worker_num; J['gh']=J.G*J.duration/3600
e=J.end/86400
print('end-time top values (days):'); print(e.round(3).value_counts().head(8))
print('max end', J.end.max(), 'dur max', J.duration.max(), 'count dur==max', (J.duration==J.duration.max()).sum())
# jobs ending within 1 hour of max end
mx=J.end.max(); cen=J.end>mx-3600
print('jobs ending within last hour of maxend:',cen.sum(), 'GPUh share', J.gh[cen].sum()/J.gh.sum())
for d in [100,120,150,180]:
    print(f' jobs with end > day {d}:', (e>d).sum())
print('duration==0:', (J.duration==0).sum(), ' dur<60s:', (J.duration<60).mean())
print('cpu==0:', (J.cpu_request==0).sum())
print('fractional cpu:', (J.cpu_request%1!=0).mean())
# end-times clustering near day 90 boundary? ends per day histogram tail
h=np.histogram(e,bins=np.arange(0,186,5))[0]; print('ends per 5day bin', h)
# durations that look like round numbers
print('top durations', J.duration.value_counts().head(10))
