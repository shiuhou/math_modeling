# Audit V1/V2: count LB recomputed by a DIFFERENT method (time grid + per-width histograms, no event sweep, no SortedList)
#              and pointwise check q(t) <= #waiting(t) in an actual SPT-strict schedule.
import pandas as pd, numpy as np
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])
assert J.job_name.is_unique
J['G']=(J.gpu_request*J.worker_num).astype(int)
dt=30.0
def q_grid(d,C,grid):
    r=d.submit_time.values; e=r+d.duration.values; G=d.G.values
    Gs=np.unique(G)[::-1]                       # widths, descending
    cnt=np.zeros((len(Gs),len(grid)),np.int64)
    for i,g in enumerate(Gs):
        m=G==g; rs=np.sort(r[m]); es=np.sort(e[m])
        cnt[i]=np.searchsorted(rs,grid,side='right')-np.searchsorted(es,grid,side='right')   # #{r<=t<e}
    tot=(cnt*Gs[:,None]).sum(0); need=np.maximum(tot-C,0)
    q=np.zeros(len(grid),np.int64); rem=need.copy()
    for i,g in enumerate(Gs):                   # greedy delete widest first, vectorised over time
        take=np.minimum(cnt[i], -(-rem//g)); q+=take; rem=np.maximum(rem-take*g,0)
    assert (rem==0).all()
    return q, cnt.sum(0)
for m in ['A10','A800-SXM4-80GB','H800','GPU-series-2']:
    d=J[J.gpu_model==m]; C=int(N[N.gpu_model==m].gpu_capacity_num.sum())
    T=(d.submit_time+d.duration).max(); grid=np.arange(dt/2,T,dt)          # midpoint rule
    q,n0=q_grid(d,C,grid)
    print(f'{m:16s} grid({dt:.0f}s midpoint) mean-wait LB = {q.sum()*dt/len(d)/3600:.4f} h ; peak q = {q.max()} ; q>=N0-C everywhere: {bool((q>=np.maximum(n0-C,0)).all())}')
# V2: pointwise check against an actual schedule (SPT-strict, A10) on the same grid
st=np.load('p2_st_sjfhol.npy')
d=J[J.gpu_model=='A10'].reset_index(drop=True); r=d.submit_time.values; p=d.duration.values
grid=np.arange(dt/2,(st+p).max(),dt); q,_=q_grid(d,2494,grid)
rs=np.sort(r); ss=np.sort(st)
waiting=np.searchsorted(rs,grid,side='right')-np.searchsorted(ss,grid,side='right')   # arrived and not yet started
viol=(waiting<q).sum()
print(f'A10 SPT-strict: grid points {len(grid)}, violations of waiting(t)>=q(t): {viol}; integral of waiting = {waiting.sum()*dt/len(d)/3600:.3f} h (simulated mean 32.91 h)')
