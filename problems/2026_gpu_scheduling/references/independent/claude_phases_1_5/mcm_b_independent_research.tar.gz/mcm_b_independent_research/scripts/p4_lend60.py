# Q3 consolidated config: dedicate L=60 whole A100 nodes (480 GPU slots, 128 vCPU each) to the 480 longest eligible t=0 A10 residents
import numpy as np, pandas as pd, warnings; warnings.filterwarnings('ignore')
import sim_node as SN, p2_sim as S
L=60; H=8*L
d=SN.J[SN.J.gpu_model=='A100-SXM4-80GB']
for pol in ['fcfs','sjf']:
    rr,pp,ak,st=SN.simulate(d,np.full(432-L,8.),np.full(432-L,128.),pol,'node'); w=(st-rr)/3600
    print(f'A100 natives on {432-L} nodes ({pol}, best-fit): mean {w.mean():.6f} h, max {w.max():.4f} h, zero-wait {np.mean(w<=0):.6f}')
A=S.A; cand=A[(A.submit_time==0)&(A.cpu_request<=16)&(A.worker_num==1)].sort_values('duration',ascending=False)
sel=cand.job_name.values[:H]; mv=np.isin(S.jid,sel)
print('moved',mv.sum(),' per lent node CPU check: 8 workers x <=16 vCPU <= 128:',bool(cand.cpu_request.values[:H].max()<=16))
base=S.sim('hol','sjf'); wb=base-S.r
keep=~mv
for nm in ['r','p','k','jid']: setattr(S,nm,getattr(S,nm)[keep])
S.n=keep.sum(); S.A=S.A[keep].reset_index(drop=True)
st=S.sim('hol','sjf'); w=st-S.r
pm=A.duration.values[mv]/3600.
dC=(wb[keep]-w).sum()/3600; dA=((S.k*S.p/3600)*(wb[keep]-w)/3600).sum()
print(f'others mean wait {wb[keep].mean()/3600:.2f} -> {w.mean()/3600:.2f} h ; sigma* count {1+dC/pm.sum():.3f} ; sigma* area {1+dA/(pm**2).sum():.3f}')
