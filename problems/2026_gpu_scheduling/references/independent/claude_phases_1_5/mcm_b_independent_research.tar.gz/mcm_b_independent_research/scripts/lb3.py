import pandas as pd, numpy as np
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])
J['G']=J.gpu_request*J.worker_num; J['C']=J.cpu_request*J.worker_num
capG=N.groupby('gpu_model').gpu_capacity_num.sum(); capC=N.groupby('gpu_model').cpu_num.sum()
def Bbound(r,p,k,C):
    # exact event-based Lindley of integral(O0 - C)
    ev=np.concatenate([r,r+p]); w=np.concatenate([k,-k]); o=np.argsort(ev,kind='stable'); t=ev[o]; occ=np.cumsum(w[o])
    B=0.; I=0.; peak=0.; tpk=0
    for i in range(len(t)-1):
        dt=t[i+1]-t[i]
        if dt<=0: continue
        s=occ[i]-C
        if s>=0:
            I+=B*dt+s*dt*dt/2; B+=s*dt
        else:
            tz=B/(-s)
            if tz>=dt: I+=B*dt+s*dt*dt/2; B+=s*dt
            else: I+=B*tz/2; B=0.
        if B>peak: peak=B; tpk=t[i+1]
    return I,peak,tpk
for m in capG.index:
    d=J[J.gpu_model==m]; r=d.submit_time.values; p=d.duration.values
    a=d.G.values*p
    I,pk,tp=Bbound(r,p,d.G.values.astype(float),capG[m])
    Ic,pkc,tpc=Bbound(r,p,d.C.values,capC[m])
    print(f'{m:16s} GPU: LB sum aW/sum a = {I/a.sum()/3600:8.2f} h, peak backlog {pk/capG[m]/3600:7.1f} pool-h @ d{tp/86400:.1f} | CPU-weighted LB {Ic/(d.C.values*p).sum()/3600:8.2f} h')
