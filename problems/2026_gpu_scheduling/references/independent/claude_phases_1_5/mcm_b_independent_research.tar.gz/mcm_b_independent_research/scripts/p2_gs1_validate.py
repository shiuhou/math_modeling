# independent node ledger check for GS1 ratio-matched FCFS run
import numpy as np, heapq, sys, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
import sim_node as SN
exec(open('p2_gs1.py').read().split("for pol in sys.argv")[0])
orig=heapq.heappush; runs=[]
def hp(h,item):
    if isinstance(item,tuple) and len(item)==3 and isinstance(item[2],list): runs.append(item)
    return orig(h,item)
SN.heapq.heappush=hp; SN.place=ratio_place
r,p,ak,st=SN.simulate(d,capg,capc,'fcfs','node'); SN.heapq.heappush=orig
g=d.gpu_request.values.astype(float); c=d.cpu_request.values.astype(float); kk=d.worker_num.values
ev=[]
for (e,j,al) in runs:
    assert sum(x for _,x in al)==kk[j]
    for i,x in al: ev.append((st[j],1,i,x*g[j],x*c[j])); ev.append((e,0,i,-x*g[j],-x*c[j]))
ev.sort(key=lambda z:(z[0],z[1])); ug=np.zeros(len(capg)); uc=np.zeros(len(capg)); viol=0
for t,typ,i,dg,dc in ev:
    ug[i]+=dg; uc[i]+=dc; viol+= (ug[i]>capg[i]+1e-9) or (uc[i]>capc[i]+1e-6)
print('started',len(runs),'violations',viol,'max wait s',(st-r).max())
