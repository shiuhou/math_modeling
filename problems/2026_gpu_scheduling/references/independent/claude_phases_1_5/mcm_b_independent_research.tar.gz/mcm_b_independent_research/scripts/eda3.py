import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_columns',30)
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])
J['G']=J.gpu_request*J.worker_num; J['C']=J.cpu_request*J.worker_num
J['gh']=J.G*J.duration/3600
cap=N.groupby('gpu_model').gpu_capacity_num.sum()
print('jobs at t=0:', (J.submit_time==0).sum()); print(J[J.submit_time==0].groupby('gpu_model').agg(n=('G','size'),G=('G','sum'),medd=('duration','median')))
print('submit within first hour', (J.submit_time<3600).sum())
# zero-wait occupancy
H=np.arange(0,185*24)*3600.
for m,d in J.groupby('gpu_model'):
    s=d.submit_time.values; e=s+d.duration.values; g=d.G.values
    ev=np.concatenate([s,e]); w=np.concatenate([g,-g]); o=np.argsort(ev,kind='stable')
    t=ev[o]; c=np.cumsum(w[o])
    idx=np.searchsorted(t,H,side='right')-1; occ=np.where(idx>=0,c[np.maximum(idx,0)],0)
    C=cap[m]; r=occ/C
    day=lambda D: r[D*24]
    print(f"{m:16s} cap={C:5d} occ/cap: d0={day(0):.2f} d7={day(7):.2f} d30={day(30):.2f} d60={day(60):.2f} d89={day(89):.2f} max={r[:90*24].max():.2f} mean(0-90)={r[:90*24].mean():.2f} frac_hours>1={(r[:90*24]>1).mean():.2f}")
    # long-running jobs share
    for th in [24,168,720]:
        mask=d.duration>th*3600
        print(f"    dur>{th}h: jobs {mask.mean()*100:.2f}%  GPUh share {d.gh[mask].sum()/d.gh.sum()*100:.1f}%")
    sgh=np.sort(d.gh.values)[::-1]; cs=np.cumsum(sgh)/sgh.sum(); n=len(sgh)
    print(f"    top1% jobs GPUh share {cs[int(0.01*n)-1]*100:.1f}%, top0.1% {cs[max(int(0.001*n)-1,0)]*100:.1f}%, top10% {cs[int(0.1*n)-1]*100:.1f}%")
