# Phase 2 standalone A10 simulator (identical 1-GPU machines; reads only the official CSV)
import pandas as pd, numpy as np, heapq, sys, time
from sortedcontainers import SortedList
SRC=__import__('os').environ['MCM_JOB_CSV']
J=pd.read_csv(SRC); A=J[J.gpu_model=='A10'].reset_index(drop=True)
r=A.submit_time.values.astype(float); p=A.duration.values.astype(float); k=A.worker_num.values.astype(int); jid=A.job_name.values
M=2494; n=len(r)

def sim(rule='hol', key='sjf', lane=None, lane_keep=False, mice_key='sjf', iso=None, scan=500, log_gang=False):
    """rule: hol | skip | easy (single reservation for blocked head, backfill if ends before shadow or fits in extra)
       key : sjf=(p,r,id) | fcfs=(r,id)
       lane: (R,tau) mice (p<=tau) served first in own queue; elephants need free-k>=R. lane_keep: keep R after arrivals end.
       mice_key: order inside mice queue (sjf|fcfs); mice queue uses same rule (hol/skip) as main.
       iso : run an isolated system of `iso` machines containing only mice (p<=tau) -> used for decoupling test."""
    kf={'sjf':lambda j:(p[j],r[j],jid[j]),'fcfs':lambda j:(r[j],jid[j])}
    mk=kf[mice_key]; ek=kf[key]
    cap=M if iso is None else iso
    jobs=np.arange(n) if iso is None else np.nonzero(p<=lane[1])[0]
    order=jobs[np.lexsort((jid[jobs],r[jobs]))]
    st=np.full(n,np.nan); Qm=[];Qe=[];run=[]; ends=SortedList(); free=cap; ai=0; N=len(order)
    gang=[]  # (job, free_before_release, released, unit_waiting) for k>=2 starts
    def start(j,t):
        nonlocal free
        st[j]=t; free-=k[j]; heapq.heappush(run,(t+p[j],k[j])); ends.add((t+p[j],k[j]))
    while ai<N or Qm or Qe or run:
        t=min(r[order[ai]] if ai<N else np.inf, run[0][0] if run else np.inf)
        fb=free; rel=0
        while run and run[0][0]<=t:
            e,kk=heapq.heappop(run); ends.remove((e,kk)); free+=kk; rel+=kk
        while ai<N and r[order[ai]]<=t:
            j=order[ai]; ai+=1
            if lane is not None and (iso is not None or p[j]<=lane[1]): heapq.heappush(Qm,(mk(j),j))
            else: heapq.heappush(Qe,(ek(j),j))
        queues=[(Qm,0),(Qe,(lane[0] if (lane is not None and (ai<N or lane_keep)) else 0))] if lane is not None else [(Qe,0)]
        for Q,res in queues:
            if not Q: continue
            sk=[]
            while Q and free>res:
                it=Q[0]; j=it[1]
                if k[j]<=free-res:
                    heapq.heappop(Q)
                    if log_gang and k[j]>=2: gang.append((j,fb,rel))
                    start(j,t); continue
                if rule=='hol': break
                if rule=='skip':
                    sk.append(heapq.heappop(Q))
                    if len(sk)>scan: break
                    continue
                # EASY: reservation for head h
                h=heapq.heappop(Q); need=k[h[1]]-(free-res); acc=0; shadow=np.inf; extra=0
                for (e,kk) in ends:
                    acc+=kk
                    if acc>=need: shadow=e; extra=acc-need; break
                cnt=0; sk2=[]
                while Q and free>res and cnt<scan:
                    it2=heapq.heappop(Q); j2=it2[1]; cnt+=1
                    if k[j2]<=free-res and (t+p[j2]<=shadow or k[j2]<=extra):
                        if t+p[j2]>shadow: extra-=k[j2]
                        if log_gang and k[j2]>=2: gang.append((j2,fb,rel))
                        start(j2,t)
                    else: sk2.append(it2)
                for it2 in sk2: heapq.heappush(Q,it2)
                heapq.heappush(Q,h); break
            for it in sk: heapq.heappush(Q,it)
    return (st,gang) if log_gang else st

def summ(name,st,extra=''):
    w=(st-r)/3600; mice=p<=3600; a=k*p; mw=mice&(k>1)
    print(f'{name:30s} mean {w.mean():6.2f} | med {np.median(w)*60:6.2f}m | p95 {np.percentile(w,95):7.2f} | p99 {np.percentile(w,99):7.1f} | max {w.max()/24:6.1f}d | areaW {(a*w).sum()/a.sum():6.1f} | mice max {w[mice].max():7.2f} | multi-mice max {w[mw].max():7.2f} | k>=2 mean {w[k>1].mean():7.1f} | {extra}',flush=True)
    return w
