# Q3: day-0 re-homing of t=0 A10 residents onto A100 spare capacity = laminar-matroid greedy (longest first)
import pandas as pd, numpy as np
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])
J['G']=J.gpu_request*J.worker_num; J['C']=J.cpu_request*J.worker_num
dt=3600.; grid=np.arange(0,200*86400,dt)
def occ(d,col):
    s=d.submit_time.values; e=s+d.duration.values; g=d[col].values.astype(float)
    ev=np.concatenate([s,e]); w=np.concatenate([g,-g]); o=np.argsort(ev,kind='stable'); t=ev[o]; c=np.cumsum(w[o])
    # max occupancy within each grid hour (conservative for host spare)
    ix=np.searchsorted(t,grid,side='right')-1
    mx=np.empty(len(grid))
    for i in range(len(grid)-1):
        lo=max(ix[i],0); hi=max(ix[i+1],0); mx[i]=c[lo:hi+1].max()
    mx[-1]=c[max(ix[-1],0)]
    return mx
h=J[J.gpu_model=='A100-SXM4-80GB']; G0=3456; C0=55296
spareG=G0-occ(h,'G'); spareC=C0-occ(h,'C')
Ht=np.floor(np.minimum(spareG,spareC/16.)).astype(int)
print('A100 hourly-max-occupancy spare (GPU, CPU/16-adjusted): min',Ht.min(),' mean',Ht[:90*24].mean())
a=J[J.gpu_model=='A10']
cand=a[(a.submit_time==0)&(a.cpu_request<=16)&(a.worker_num==1)].sort_values('duration',ascending=False)
print('t=0 A10 residents:',(a.submit_time==0).sum(),' eligible (cpu<=16, 1 worker):',len(cand),' eligible GPUh share of A10:',(cand.duration.sum()/3600)/(a.G*a.duration/3600).sum())
for name,H in [('time-varying H(t) [offline, in-sample]',Ht),('constant H=min_t H(t)',np.full_like(Ht,Ht.min()))]:
    cnt=np.zeros(len(grid),int); sel=[]
    for j,pj in zip(cand.job_name.values,cand.duration.values):
        L=int(np.ceil(pj/dt))
        if np.all(cnt[:L]+1<=H[:L]): cnt[:L]+=1; sel.append(j)
    S=a.job_name.isin(sel)
    print(f'{name}: moved {len(sel)} jobs, moved GPUh share of A10 {(a.G[S]*a.duration[S]).sum()/(a.G*a.duration).sum():.3f}')
    # A10 bounds after removal
    rest=a[~S]; r=rest.submit_time.values; p=rest.duration.values; g=rest.G.values.astype(float)
    ev=np.concatenate([r,r+p]); w=np.concatenate([g,-g]); o=np.argsort(ev,kind='stable'); t=ev[o]; c=np.cumsum(w[o])
    seg=np.diff(t); lev=c[:-1]; Cc=2494
    # area LB via Lindley of O0-C
    B=0.; I=0.
    for dtt,lv in zip(seg,lev):
        s=lv-Cc
        if s>=0: I+=B*dtt+s*dtt*dtt/2; B+=s*dtt
        else:
            tz=B/(-s)
            if tz>=dtt: I+=B*dtt+s*dtt*dtt/2; B+=s*dtt
            else: I+=B*tz/2; B=0.
    # count LB over ALL A10 jobs (moved ones wait 0): sum over remaining
    ev2=np.concatenate([r,r+p]); w2=np.concatenate([np.ones(len(r)),-np.ones(len(r))]); o2=np.argsort(ev2,kind='stable'); t2=ev2[o2]; c2=np.cumsum(w2[o2])
    LBc=(np.maximum(c2[:-1]-Cc,0)*np.diff(t2)).sum()
    print(f'   A10 area-weighted LB (all A10 work incl. moved at 0 wait): {I/(a.G*a.duration).sum()/3600:.1f} h ; count-mean LB over all {len(a)} A10 jobs: {LBc/len(a)/3600:.2f} h')
