# Phase 2: count-weighted lower bounds for total waiting (any non-preemptive OR preemptive schedule)
# LB1 (instantaneous): waiting(t) >= N0(t) - C, N0 = #jobs with r<=t<r+p (must be present), running count <= C
# LB2 (memory): present(t) >= A(t) - Dep_max(t); Dep_max(t) <= Moore-Hodgson on reversed single machine of speed C
import pandas as pd, numpy as np, heapq, sys, time
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])
m=sys.argv[1] if len(sys.argv)>1 else 'A10'
d=J[J.gpu_model==m]; C=int(N[N.gpu_model==m].gpu_capacity_num.sum())
r=d.submit_time.values.astype(float); p=d.duration.values.astype(float); G=(d.gpu_request*d.worker_num).values.astype(float); a=G*p
n=len(r)
# LB1 exact event integration
ev=np.concatenate([r,r+p]); w=np.concatenate([np.ones(n),-np.ones(n)]); o=np.lexsort((-w,ev)) # arrivals before departures at same t (conservative? see note)
o=np.argsort(ev,kind='stable'); t=ev[o]; c=np.cumsum(w[o])
seg=np.diff(t); lev=c[:-1]
LB1=(np.maximum(lev-C,0)*seg).sum()
print(f'{m}: n={n} C={C}  LB1 sum W >= {LB1/3600:.4g} job-h  -> mean wait >= {LB1/n/3600:.3f} h')
# LB2 on grid
step=6*3600.; grid=np.arange(0,max((r+p).max(),r.max())+2*step,step)
order_end=np.argsort(r+p); endsorted=(r+p)[order_end]
rs=np.sort(r)
def MH(T):
    k=np.searchsorted(endsorted,T,side='right'); idx=order_end[:k]   # E_T
    if k==0: return 0
    dl=T-r[idx]; oo=np.argsort(dl,kind='stable')
    h=[]; cum=0.
    for j in idx[oo]:
        heapq.heappush(h,-a[j]); cum+=a[j]
        if cum> C*(T-r[j])+1e-6: cum+=heapq.heappop(h)   # drop largest
    return len(h)
t0=time.time()
mh=np.array([MH(T) for T in grid]); print('MH grid done',time.time()-t0,'s')
A=np.searchsorted(rs,grid,side='right')
# rigorous step bound on [g_i,g_{i+1}): waiting >= A(g_i) - MH(g_{i+1}) - C
lb2=np.maximum(A[:-1]-mh[1:]-C,0)*step
# min N0 over each grid interval (exact from events)
N0min=np.empty(len(grid)-1)
ix=np.searchsorted(t,grid,side='right')-1
for i in range(len(grid)-1):
    lo=max(ix[i],0); hi=max(ix[i+1],0)
    N0min[i]=c[lo:hi+1].min() if hi>=lo else c[lo]
comb=np.maximum(np.maximum(N0min-C,0)*step, lb2)
print(f'  LB2 (memory, grid) mean wait >= {lb2.sum()/n/3600:.3f} h ; combined step bound >= {comb.sum()/n/3600:.3f} h')
print('  peak forced waiting count LB1:',int(np.maximum(lev-C,0).max()),' LB2:',int(np.maximum(A[:-1]-mh[1:]-C,0).max()))
np.save(f'p2_lbcount_{m}.npy',np.vstack([grid[:-1],np.maximum(A[:-1]-mh[1:]-C,0),np.maximum(N0min-C,0)]))
