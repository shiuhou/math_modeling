# Does the ratio-matched GS1 run ever place a worker on a node whose CPU/GPU ratio is below the worker's own ratio
# ("downward fallback", the only way CPU can strand GPUs)? Also: max 1-GPU-node usage and multi-GPU worker placements.
import numpy as np, warnings; warnings.filterwarnings('ignore')
exec(open("audit_v3.py").read().split("name=nn.node_name.values")[0])
import sim_node as SN
log=[]
def logged(fg,fc,k,g,c):
    al=ratio_matched(fg,fc,k,g,c)
    if al is not None:
        rho=c/g
        for i,x in al: log.append((g,rho,ratio[i],x))
    return al
SN.place=logged; r,p,ak,st=SN.simulate(d,capg,capc,'fcfs','node')
L=np.array(log)
down=L[:,2]<L[:,1]-1e-9
print('placements',len(L),' worker-placements',int(L[:,3].sum()),' downward-fallback worker-placements',int(L[down,3].sum()),' max wait',(st-r).max())
print('multi-GPU worker placements (g,ratio of node):',[(int(a),float(b)) for a,_,b,_ in L[L[:,0]>1]])
