import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_columns',30)
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])
J['G']=J.gpu_request*J.worker_num; J['C']=J.cpu_request*J.worker_num
J['gh']=J.G*J.duration/3600
for m,d in J.groupby('gpu_model'):
    print('=====',m, len(d))
    print(' gpu_request', d.gpu_request.value_counts().sort_index().to_dict())
    print(' worker_num q', d.worker_num.quantile([.5,.9,.99,.999,1]).to_dict(), 'multiworker frac', (d.worker_num>1).mean())
    print(' cpu_request q', d.cpu_request.quantile([0,.5,.9,.99,1]).to_dict())
    print(' cpu/gpu per worker q', (d.cpu_request/d.gpu_request).quantile([.5,.9,.99,1]).to_dict())
    print(' duration q (h)', (d.duration/3600).quantile([0,.1,.5,.9,.99,1]).round(3).to_dict())
    nm=N[N.gpu_model==m]
    # feasibility per worker: exists node with gpu>=g and cpu>=c
    feas=d.apply(lambda r: ((nm.gpu_capacity_num>=r.gpu_request)&(nm.cpu_num>=r.cpu_request)).any(),axis=1) if len(d)<20000 else None
    if feas is not None: print(' infeasible workers', (~feas).sum())
