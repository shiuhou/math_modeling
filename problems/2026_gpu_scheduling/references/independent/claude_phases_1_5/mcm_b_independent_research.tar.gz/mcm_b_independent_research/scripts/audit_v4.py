# Audit V4: integer-exact ledger (CPU in 1/100 vCPU) for the GS1 ratio-matched schedule + tie/simultaneity facts
import numpy as np, heapq, warnings; warnings.filterwarnings('ignore')
import sim_node as SN
exec(open("audit_v3.py").read().split("name=nn.node_name.values")[0])
d=d.reset_index(drop=True)
cu=np.rint(d.cpu_request.values*100); assert np.allclose(cu,d.cpu_request.values*100,atol=1e-6); cu=cu.astype(np.int64)
gu=d.gpu_request.values.astype(np.int64); kk=d.worker_num.values.astype(np.int64)
orig=heapq.heappush; runs=[]
def hp(h,item):
    if isinstance(item,tuple) and len(item)==3 and isinstance(item[2],list): runs.append(item)
    return orig(h,item)
SN.heapq.heappush=hp; SN.place=ratio_matched
r,p,ak,st=SN.simulate(d,capg,capc,'fcfs','node'); SN.heapq.heappush=orig
ids=set(); ev=[]
for (e,j,al) in runs:
    ids.add(j); assert sum(x for _,x in al)==kk[j] and st[j]==r[j] and e==r[j]+p[j]
    for i,x in al: ev.append((st[j],1,i,x*gu[j],x*cu[j])); ev.append((e,0,i,-x*gu[j],-x*cu[j]))
ev.sort(key=lambda z:(z[0],z[1]))
CG=capg.astype(np.int64); CC=(capc*100).astype(np.int64); ug=np.zeros(len(CG),np.int64); uc=np.zeros(len(CG),np.int64); bad=0
for t,typ,i,dg,dc in ev:
    ug[i]+=dg; uc[i]+=dc; bad+=(ug[i]>CG[i]) or (uc[i]>CC[i]) or (ug[i]<0) or (uc[i]<0)
print('jobs started',len(ids),'/',len(d),' integer-ledger violations',bad,' final zero',(ug==0).all() and (uc==0).all())
print('fractional-CPU jobs',int((d.cpu_request%1!=0).sum()),' jobs sharing a submit time with another GS1 job',int(d.submit_time.duplicated(keep=False).sum()),
      ' (submit==some other job end) events',int(np.isin(d.submit_time.values,(d.submit_time+d.duration).values).sum()))
