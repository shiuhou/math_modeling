import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_columns',30)
J=pd.read_csv(__import__('os').environ['MCM_JOB_CSV'])
J['end']=J.submit_time+J.duration
J['G']=J.gpu_request*J.worker_num; J['C']=J.cpu_request*J.worker_num; J['gh']=J.G*J.duration/3600
TE=15897600.
print('exact ends', J.end.sub(TE).abs().describe())
J['rc']=(J.end-TE).abs()<=86400*0.01
J['lc']=J.submit_time==0
g=J.groupby('gpu_model').apply(lambda d: pd.Series({'n':len(d),'rc_n':d.rc.sum(),'rc_GPUh%':100*d.gh[d.rc].sum()/d.gh.sum(),
   'lc_n':d.lc.sum(),'lc_GPUh%':100*d.gh[d.lc].sum()/d.gh.sum(),'either_GPUh%':100*d.gh[d.rc|d.lc].sum()/d.gh.sum()}))
print(g)
# A10 load excluding censored services
N=pd.read_csv(__import__('os').environ['MCM_NODE_CSV'])
cap=N.groupby('gpu_model').gpu_capacity_num.sum()
H=np.arange(0,90*24)*3600.
def occ(d):
    s=d.submit_time.values; e=s+d.duration.values; g=d.G.values
    ev=np.concatenate([s,e]); w=np.concatenate([g,-g]); o=np.argsort(ev,kind='stable')
    t=ev[o]; c=np.cumsum(w[o]); idx=np.searchsorted(t,H,side='right')-1
    return np.where(idx>=0,c[np.maximum(idx,0)],0)
for m in cap.index:
    d=J[J.gpu_model==m]
    a=occ(d)/cap[m]; b=occ(d[~d.rc & ~d.lc])/cap[m]; c=occ(d[d.rc|d.lc])/cap[m]
    print(f'{m:16s} all mean {a.mean():.2f}  censored-only mean {c.mean():.2f}  uncensored mean {b.mean():.2f} max {b.max():.2f}')
# A10 duration-weighted cpu
d=J[J.gpu_model=='A10']
print('A10 GPUh-weighted CPU per GPU', (d.gh*d.cpu_request).sum()/d.gh.sum())
for th in [1,24,168]:
    m=d.duration>th*3600
    print(f'  A10 dur>{th}h cpu quantiles', d.cpu_request[m].quantile([.25,.5,.75,.9]).to_dict(), 'GPUh-weighted mean', (d.gh[m]*d.cpu_request[m]).sum()/d.gh[m].sum())
