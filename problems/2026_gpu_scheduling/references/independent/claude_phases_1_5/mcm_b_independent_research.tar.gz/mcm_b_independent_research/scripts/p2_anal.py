import numpy as np, pandas as pd
from p2_sim import r,p,k,M,n
def idle_while_waiting(st):
    # machine-hours idle while at least one job waits
    ev=np.concatenate([st,st+p,r,st]); 
    dbusy=np.concatenate([k,-k,np.zeros(n),np.zeros(n)]); dq=np.concatenate([np.zeros(n),np.zeros(n),np.ones(n),-np.ones(n)])
    o=np.argsort(ev,kind='stable'); t=ev[o]; b=np.cumsum(dbusy[o]); q=np.cumsum(dq[o])
    seg=np.diff(t); idle=(M-b[:-1]); mask=q[:-1]>0
    return (idle*seg*mask).sum()/3600, (idle*seg*mask)[t[:-1]<90*86400].sum()/3600
for name in ['sjfhol','sjfskip','sjfeasy']:
    st=np.load(f'p2_st_{name}.npy'); a,b=idle_while_waiting(st)
    print(f'{name}: idle machine-hours while queue nonempty: total {a:,.0f}, in [0,90d] {b:,.0f}  (= {b/M:.2f} full-pool hours)')
# gang horizon from SJF-HOL: k-th smallest residual (free machines count as residual 0)
st=np.load('p2_st_sjfhol.npy'); e=st+p
snaps=np.arange(7,90,0.25)*86400
K=[1,2,5,10,20,32,60,100,200,500]
H=[]
for t in snaps:
    run=(st<=t)&(e>t); res=np.repeat(e[run]-t,k[run]); free=M-k[run].sum()
    res=np.sort(np.concatenate([np.zeros(max(free,0)),res]))
    H.append([res[kk-1]/3600 for kk in K])
H=np.array(H)
print('gang horizon h_k (hours) under SJF-HOL, days 7-90 snapshots: median / p90')
for i,kk in enumerate(K): print(f'  k={kk:4d}: median {np.median(H[:,i]):9.2f}  p90 {np.percentile(H[:,i],90):9.2f}')
# W/p by duration class (SJF-HOL)
w=st-r
bins=[0,3600,86400,7*86400,30*86400,np.inf]; lab=['<=1h','1h-1d','1-7d','7-30d','>30d']
c=pd.cut(p,bins,labels=lab,include_lowest=True)
df=pd.DataFrame({'c':c,'w_h':w/3600,'ratio':w/p,'gh':k*p/3600})
g=df.groupby('c',observed=True).agg(n=('w_h','size'),GPUh_share=('gh','sum'),mean_w_h=('w_h','mean'),p90_w_h=('w_h',lambda x:np.percentile(x,90)),med_ratio=('ratio','median'),frac_ratio_gt1=('ratio',lambda x:(x>1).mean()),frac_ratio_gt0p5=('ratio',lambda x:(x>.5).mean()))
g['GPUh_share']=g.GPUh_share/g.GPUh_share.sum()
print(g.round(3).to_string())
