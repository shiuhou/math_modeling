# Erratum 6: area-weighted LB  int_0^inf B(t) dt  where B = Lindley(O0 - C).
# Event integration stops at t* = last event = max(r+p); after t*, O0 = 0 and B decays at rate C, adding B(t*)^2/(2C).
import os, numpy as np, pandas as pd
J=pd.read_csv(os.environ['MCM_JOB_CSV']); N=pd.read_csv(os.environ['MCM_NODE_CSV'])
J['G']=J.gpu_request*J.worker_num
def area_lb(r,p,G,C):
    ev=np.concatenate([r,r+p]); w=np.concatenate([G,-G]).astype(float); o=np.argsort(ev,kind='stable'); t=ev[o]; occ=np.cumsum(w[o])
    B=0.; I=0.
    for i in range(len(t)-1):
        dt=t[i+1]-t[i]
        if dt<=0: continue
        s=occ[i]-C
        if s>=0: I+=B*dt+s*dt*dt/2; B+=s*dt
        else:
            tz=B/(-s)
            if tz>=dt: I+=B*dt+s*dt*dt/2; B+=s*dt
            else: I+=B*tz/2; B=0.
    assert abs(occ[-1])<1e-6       # all work done at t*: O0(t*)=0
    tail=B*B/(2*C)
    return I, tail, B, t[-1]
def show(label,d,C,denom):
    I,tail,Bs,ts=area_lb(d.submit_time.values.astype(float),d.duration.values.astype(float),d.G.values,C)
    print(f'{label:34s} t*={ts!r} s  B(t*)={Bs!r} GPU*s | front={I!r} | tail={tail!r} | total={I+tail!r} GPU*s^2 | '
          f'normalised total/denominator = {(I+tail)/denom/3600!r} h (front only {I/denom/3600!r} h)')
for m,d in J.groupby('gpu_model'):
    C=float(N[N.gpu_model==m].gpu_capacity_num.sum()); show(m,d,C,(d.G*d.duration).sum())
# initial-submission-batch removal configurations (Q3), normalised by the ORIGINAL A10 area (fixed denominator)
A=J[J.gpu_model=='A10']; denom=(A.G*A.duration).sum()
cand=A[(A.submit_time==0)&(A.cpu_request<=16)&(A.worker_num==1)].sort_values('duration',ascending=False)
for h in (480,534):
    rest=A[~A.job_name.isin(cand.job_name.values[:h])]
    show(f'A10 minus {h} longest batch jobs',rest,2494.,denom)
