#!/usr/bin/env bash
# Usage: MCM_JOB_CSV=/path/job_info_clean.csv MCM_NODE_CSV=/path/node_info_df.csv bash run_core_checks.sh
set -euo pipefail
: "${MCM_JOB_CSV:?set MCM_JOB_CSV}"; : "${MCM_NODE_CSV:?set MCM_NODE_CSV}"
HERE=$(cd "$(dirname "$0")" && pwd); OUT=$HERE/results/core_run; mkdir -p "$OUT"; cd "$HERE/scripts"
echo "== data hashes" | tee "$OUT/00_hashes.txt"; sha256sum "$MCM_JOB_CSV" "$MCM_NODE_CSV" | tee -a "$OUT/00_hashes.txt"
run(){ echo "== $*"; python3 "$@" 2>&1 | grep -v Warning | tee "$OUT/$(echo "$*" | tr ' /:' '___').txt"; }
run lb3.py                       # area-weighted LB per pool (Theorem: identity + Lindley bound)
run p2_countlb_all.py            # count LB per pool (event sweep)

run p2_run.py hol                # SPT-strict A10 schedule -> p2_st_sjfhol.npy
run p2_run.py skip               # SPT-skip A10 schedule (gang starvation evidence)
run p2_run.py easy               # SPT + single reservation
run p2_run.py decouple           # decoupling theorem test (FCFS mice, R=50 kept)
run audit_v1.py                  # count LB by second method + pointwise check vs SPT-strict
run p2_anal.py                   # idle cost, gang horizon h_k, W/p table
run p4_checks.py truncated       # truncated-delay decomposition
run p4_checks.py renewal         # renewal prediction of h_k
run p4_checks.py gs1cond         # GS1 class occupancies
run audit_v3.py                  # GS1 fair placement comparison
run audit_v4.py                  # GS1 integer ledger
run p4_gs1_fallback.py           # GS1 downward-fallback count
run p2_rehome.py                 # Q3 fluid re-homing bounds
run p4_lend60.py                 # Q3 node-level verified config (60 dedicated A100 nodes)
# ---- erratum checks (Phase 5) ----
run e1_area_tail.py              # E6: area LB incl. post-t* tail B(t*)^2/(2C); front/tail/total at full precision
run e2_shape_exact.py            # E3: shape bound with SEPARATE GPU-heavy / CPU-heavy counts, exact over all event intervals
run e3_toy_counterexamples.py    # E3/E4: exhaustive checks of the hand counterexamples
run e4_sigma_fixed.py            # E5: sigma* on fixed population and native weights; fixed-denominator normalisation
echo "done -> $OUT"
