# Problem B baseline code supplement candidate

This package contains the reproducible source and entry points for the integrated baseline. It excludes the supplied raw CSVs and large schedule/evidence archives; those remain identified by hash in `paper_sources.json` and the release record. No scheduler or parameter search is run by this package.

Fixed source commits: Q1 `7075317883808b1cd7f80cadf3980be291c69cf0`, Q2 `b91918bb084848b93de642ad4e3ea0a7d3f25e68`, Q3 `170cc37a820e830a969cb1b1cd3cadb1e8fdf256`.

The normal verification entry points are the repository checks and tests documented in the release record. Full-trace reproduction requires the competition-provided CSVs at the documented paths and adequate memory/time; this supplement does not include those inputs.
